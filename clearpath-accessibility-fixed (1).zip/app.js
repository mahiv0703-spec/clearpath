const testCatalog = {
  ssc: {
    label: "SSC",
    subject: "SSC COMPETITIVE EXAM",
    durationSeconds: 600,
    description: "General awareness, aptitude, and exam reasoning practice.",
    questions: [
      {
        en: { title: "If 20% of a number is 50, what is the number?", options: ["200", "250", "300", "350"] },
        hi: { title: "यदि किसी संख्या का 20% 50 है, तो वह संख्या क्या है?", options: ["200", "250", "300", "350"] },
        answer: 1,
      },
      {
        en: { title: "Which constitutional body conducts elections in India?", options: ["Election Commission of India", "Union Public Service Commission", "Comptroller and Auditor General", "Finance Commission"] },
        hi: { title: "भारत में चुनाव कौन सा संवैधानिक निकाय करवाता है?", options: ["भारत निर्वाचन आयोग", "संघ लोक सेवा आयोग", "नियंत्रक एवं महालेखा परीक्षक", "वित्त आयोग"] },
        answer: 0,
      },
      {
        en: { title: "A sum of ₹800 is divided in the ratio 3:5. What is the smaller share?", options: ["₹240", "₹300", "₹360", "₹400"] },
        hi: { title: "₹800 को 3:5 के अनुपात में बाँटा गया है। छोटा हिस्सा कितना है?", options: ["₹240", "₹300", "₹360", "₹400"] },
        answer: 2,
      },
      {
        en: { title: "Solve the equation shown below for x.", options: ["10", "12", "14", "16"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mi>x</mi><mo>+</mo><mn>7</mn><mo>=</mo><mn>19</mn></mrow></math>', mathLabel: "x plus 7 equals 19." },
        hi: { title: "नीचे दिए गए समीकरण में x का मान ज्ञात कीजिए।", options: ["10", "12", "14", "16"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mi>x</mi><mo>+</mo><mn>7</mn><mo>=</mo><mn>19</mn></mrow></math>', mathLabel: "x प्लस 7 बराबर 19." },
        answer: 1,
      },
      {
        en: { title: "Which planet is known as the Red Planet?", options: ["Venus", "Mars", "Jupiter", "Mercury"] },
        hi: { title: "किस ग्रह को लाल ग्रह कहा जाता है?", options: ["शुक्र", "मंगल", "बृहस्पति", "बुध"] },
        answer: 1,
      },
      {
        en: { title: "What is three quarters of 80?", options: ["40", "50", "60", "70"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mfrac><mn>3</mn><mn>4</mn></mfrac><mo>×</mo><mn>80</mn><mo>=</mo><mo>?</mo></mrow></math>', mathLabel: "three fourths times 80 equals question mark." },
        hi: { title: "80 का तीन चौथाई कितना है?", options: ["40", "50", "60", "70"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mfrac><mn>3</mn><mn>4</mn></mfrac><mo>×</mo><mn>80</mn><mo>=</mo><mo>?</mo></mrow></math>', mathLabel: "तीन बटा चार गुणा 80 बराबर प्रश्नवाचक चिन्ह." },
        answer: 2,
      },
      {
        en: { title: "Who is the head of the Union executive in India?", options: ["The President", "The Prime Minister", "The Chief Justice", "The Speaker"] },
        hi: { title: "भारत में संघ कार्यपालिका का प्रमुख कौन होता है?", options: ["राष्ट्रपति", "प्रधानमंत्री", "मुख्य न्यायाधीश", "लोकसभा अध्यक्ष"] },
        answer: 0,
      },
      {
        en: { title: "What is the average of 12 and 18?", options: ["12", "14", "15", "16"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mfrac><mrow><mn>12</mn><mo>+</mo><mn>18</mn></mrow><mn>2</mn></mfrac><mo>=</mo><mo>?</mo></mrow></math>', mathLabel: "12 plus 18 divided by 2 equals question mark." },
        hi: { title: "12 और 18 का औसत कितना है?", options: ["12", "14", "15", "16"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mfrac><mrow><mn>12</mn><mo>+</mo><mn>18</mn></mrow><mn>2</mn></mfrac><mo>=</mo><mo>?</mo></mrow></math>', mathLabel: "12 प्लस 18 बटा 2 बराबर प्रश्नवाचक चिन्ह." },
        answer: 2,
      },
      {
        en: { title: "Which gas do plants absorb during photosynthesis?", options: ["Oxygen", "Nitrogen", "Carbon dioxide", "Hydrogen"] },
        hi: { title: "प्रकाश संश्लेषण के दौरान पौधे कौन सी गैस अवशोषित करते हैं?", options: ["ऑक्सीजन", "नाइट्रोजन", "कार्बन डाइऑक्साइड", "हाइड्रोजन"] },
        answer: 2,
      },
      {
        en: { title: "A price rises from ₹100 to ₹120. What is the percentage increase?", options: ["10%", "15%", "20%", "25%"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mfrac><mrow><mn>120</mn><mo>−</mo><mn>100</mn></mrow><mn>100</mn></mfrac><mo>×</mo><mn>100</mn><mo>=</mo><mo>?</mo></mrow></math>', mathLabel: "120 minus 100 divided by 100, times 100, equals question mark." },
        hi: { title: "किसी वस्तु का मूल्य 100 रुपये से 120 रुपये हो जाता है। प्रतिशत वृद्धि कितनी है?", options: ["10%", "15%", "20%", "25%"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mfrac><mrow><mn>120</mn><mo>−</mo><mn>100</mn></mrow><mn>100</mn></mfrac><mo>×</mo><mn>100</mn><mo>=</mo><mo>?</mo></mrow></math>', mathLabel: "120 माइनस 100 बटा 100, गुणा 100, बराबर प्रश्नवाचक चिन्ह." },
        answer: 2,
      },
    ],
  },
  railway: {
    label: "Railway",
    subject: "RAILWAY RECRUITMENT",
    durationSeconds: 600,
    description: "Speed, arithmetic, and general reasoning for railway exams.",
    questions: [
      {
        en: { title: "A train travels at 60 kilometres per hour. How far will it travel in 18 seconds?", options: ["240 metres", "300 metres", "360 metres", "420 metres"] },
        hi: { title: "एक ट्रेन 60 किलोमीटर प्रति घंटे की गति से चलती है। 18 सेकंड में वह कितनी दूरी तय करेगी?", options: ["240 मीटर", "300 मीटर", "360 मीटर", "420 मीटर"] },
        answer: 1,
      },
      {
        en: { title: "Find the next number in the series: 12, 18, 24, 30, ?", options: ["34", "36", "38", "42"] },
        hi: { title: "श्रृंखला में अगली संख्या ज्ञात कीजिए: 12, 18, 24, 30, ?", options: ["34", "36", "38", "42"] },
        answer: 1,
      },
      {
        en: { title: "Five workers complete a job in 12 days. How many days will ten workers take at the same rate?", options: ["4 days", "6 days", "8 days", "10 days"] },
        hi: { title: "पाँच कर्मचारी एक काम को 12 दिनों में पूरा करते हैं। उसी दर पर दस कर्मचारी कितने दिनों में काम पूरा करेंगे?", options: ["4 दिन", "6 दिन", "8 दिन", "10 दिन"] },
        answer: 1,
      },
      {
        en: { title: "Solve the equation shown below for x.", options: ["4", "6", "8", "10"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mn>2</mn><mi>x</mi><mo>+</mo><mn>5</mn><mo>=</mo><mn>17</mn></mrow></math>', mathLabel: "2 x plus 5 equals 17." },
        hi: { title: "नीचे दिए गए समीकरण में x का मान ज्ञात कीजिए।", options: ["4", "6", "8", "10"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mn>2</mn><mi>x</mi><mo>+</mo><mn>5</mn><mo>=</mo><mn>17</mn></mrow></math>', mathLabel: "2 x प्लस 5 बराबर 17." },
        answer: 1,
      },
      {
        en: { title: "Which is the longest railway route in India?", options: ["Dibrugarh–Kanyakumari", "Delhi–Mumbai", "Kolkata–Chennai", "Amritsar–Kochi"] },
        hi: { title: "भारत में सबसे लंबा रेलवे मार्ग कौन सा है?", options: ["डिब्रूगढ़–कन्याकुमारी", "दिल्ली–मुंबई", "कोलकाता–चेन्नई", "अमृतसर–कोच्चि"] },
        answer: 0,
      },
      {
        en: { title: "A vehicle covers 150 km in 3 hours. What is its average speed?", options: ["30 km/h", "40 km/h", "50 km/h", "60 km/h"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mfrac><mn>150</mn><mn>3</mn></mfrac><mo>=</mo><mo>?</mo><mtext> km/h</mtext></mrow></math>', mathLabel: "150 divided by 3 equals question mark kilometres per hour." },
        hi: { title: "एक वाहन 3 घंटे में 150 किलोमीटर चलता है। इसकी औसत गति कितनी है?", options: ["30 किमी/घंटा", "40 किमी/घंटा", "50 किमी/घंटा", "60 किमी/घंटा"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mfrac><mn>150</mn><mn>3</mn></mfrac><mo>=</mo><mo>?</mo><mtext> किमी/घंटा</mtext></mrow></math>', mathLabel: "150 बटा 3 बराबर प्रश्नवाचक चिन्ह किलोमीटर प्रति घंटा." },
        answer: 2,
      },
      {
        en: { title: "Which instrument measures atmospheric pressure?", options: ["Thermometer", "Barometer", "Speedometer", "Hygrometer"] },
        hi: { title: "वायुमंडलीय दबाव मापने का यंत्र कौन सा है?", options: ["थर्मामीटर", "बैरोमीटर", "स्पीडोमीटर", "हाइग्रोमीटर"] },
        answer: 1,
      },
      {
        en: { title: "If a train leaves at 09:20 and travels for 2 hours 45 minutes, when does it arrive?", options: ["11:45", "12:05", "12:15", "12:25"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mn>09</mn><mo>:</mo><mn>20</mn><mo>+</mo><mn>2</mn><mtext> hours </mtext><mo>+</mo><mn>45</mn><mtext> minutes</mtext></mrow></math>', mathLabel: "09:20 plus 2 hours plus 45 minutes." },
        hi: { title: "एक ट्रेन 09:20 पर चलती है और 2 घंटे 45 मिनट यात्रा करती है। वह कब पहुँचेगी?", options: ["11:45", "12:05", "12:15", "12:25"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mn>09</mn><mo>:</mo><mn>20</mn><mo>+</mo><mn>2</mn><mtext> घंटे </mtext><mo>+</mo><mn>45</mn><mtext> मिनट</mtext></mrow></math>', mathLabel: "09:20 प्लस 2 घंटे प्लस 45 मिनट." },
        answer: 1,
      },
      {
        en: { title: "What is the smallest prime number?", options: ["0", "1", "2", "3"] },
        hi: { title: "सबसे छोटी अभाज्य संख्या कौन सी है?", options: ["0", "1", "2", "3"] },
        answer: 2,
      },
      {
        en: { title: "A worker earns ₹600 for 5 days. What is the daily wage?", options: ["₹100", "₹110", "₹120", "₹150"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mfrac><mn>600</mn><mn>5</mn></mfrac><mo>=</mo><mo>?</mo></mrow></math>', mathLabel: "600 divided by 5 equals question mark rupees." },
        hi: { title: "एक कर्मचारी 5 दिनों के लिए 600 रुपये कमाता है। दैनिक मजदूरी कितनी है?", options: ["₹100", "₹110", "₹120", "₹150"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mfrac><mn>600</mn><mn>5</mn></mfrac><mo>=</mo><mo>?</mo></mrow></math>', mathLabel: "600 बटा 5 बराबर प्रश्नवाचक चिन्ह रुपये." },
        answer: 2,
      },
    ],
  },
  banking: {
    label: "Banking",
    subject: "BANKING AWARENESS",
    durationSeconds: 600,
    description: "Banking awareness, interest, and numerical ability practice.",
    questions: [
      {
        en: { title: "What is the simple interest on ₹2,000 at 5% per year for 2 years?", options: ["₹100", "₹200", "₹250", "₹300"] },
        hi: { title: "₹2,000 पर 5% वार्षिक दर से 2 वर्षों का साधारण ब्याज कितना होगा?", options: ["₹100", "₹200", "₹250", "₹300"] },
        answer: 1,
      },
      {
        en: { title: "What does RBI stand for?", options: ["Reserve Bank of India", "Regional Bank of India", "Rural Banking Institution", "Reserve Board of India"] },
        hi: { title: "RBI का पूरा नाम क्या है?", options: ["भारतीय रिज़र्व बैंक", "भारत का क्षेत्रीय बैंक", "ग्रामीण बैंकिंग संस्था", "भारत का रिज़र्व बोर्ड"] },
        answer: 0,
      },
      {
        en: { title: "What is the average of 5, 10, 15, and 20?", options: ["10", "12.5", "15", "17.5"] },
        hi: { title: "5, 10, 15 और 20 का औसत कितना है?", options: ["10", "12.5", "15", "17.5"] },
        answer: 1,
      },
      {
        en: { title: "Calculate the simple interest using the formula shown.", options: ["₹100", "₹150", "₹200", "₹250"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mi>I</mi><mo>=</mo><mfrac><mrow><mn>2000</mn><mo>×</mo><mn>5</mn><mo>×</mo><mn>2</mn></mrow><mn>100</mn></mfrac></mrow></math>', mathLabel: "I equals 2000 times 5 times 2 divided by 100." },
        hi: { title: "दिए गए सूत्र का उपयोग करके साधारण ब्याज ज्ञात कीजिए।", options: ["₹100", "₹150", "₹200", "₹250"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mi>I</mi><mo>=</mo><mfrac><mrow><mn>2000</mn><mo>×</mo><mn>5</mn><mo>×</mo><mn>2</mn></mrow><mn>100</mn></mfrac></mrow></math>', mathLabel: "I बराबर 2000 गुणा 5 गुणा 2 बटा 100." },
        answer: 2,
      },
      {
        en: { title: "Which account is generally used for frequent business transactions?", options: ["Savings account", "Current account", "Fixed deposit", "Recurring deposit"] },
        hi: { title: "लगातार व्यावसायिक लेन-देन के लिए सामान्यतः किस खाते का उपयोग किया जाता है?", options: ["बचत खाता", "चालू खाता", "सावधि जमा", "आवर्ती जमा"] },
        answer: 1,
      },
      {
        en: { title: "What is 15% of ₹400?", options: ["₹40", "₹50", "₹60", "₹80"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mfrac><mn>15</mn><mn>100</mn></mfrac><mo>×</mo><mn>400</mn><mo>=</mo><mo>?</mo></mrow></math>', mathLabel: "15 divided by 100 times 400 equals question mark." },
        hi: { title: "400 रुपये का 15 प्रतिशत कितना है?", options: ["₹40", "₹50", "₹60", "₹80"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mfrac><mn>15</mn><mn>100</mn></mfrac><mo>×</mo><mn>400</mn><mo>=</mo><mo>?</mo></mrow></math>', mathLabel: "15 बटा 100 गुणा 400 बराबर प्रश्नवाचक चिन्ह." },
        answer: 2,
      },
      {
        en: { title: "Which institution regulates monetary policy in India?", options: ["SEBI", "RBI", "NITI Aayog", "NABARD"] },
        hi: { title: "भारत में मौद्रिक नीति को कौन सी संस्था नियंत्रित करती है?", options: ["सेबी", "आरबीआई", "नीति आयोग", "नाबार्ड"] },
        answer: 1,
      },
      {
        en: { title: "A deposit doubles in 8 years at simple interest. What is the total amount as a multiple of the principal?", options: ["One half", "One", "Two", "Three"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mi>A</mi><mo>=</mo><mn>2</mn><mi>P</mi></mrow></math>', mathLabel: "A equals 2 P." },
        hi: { title: "साधारण ब्याज पर कोई जमा 8 वर्षों में दोगुनी हो जाती है। मूलधन के कितने गुना राशि होगी?", options: ["आधा", "एक", "दो", "तीन"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mi>A</mi><mo>=</mo><mn>2</mn><mi>P</mi></mrow></math>', mathLabel: "A बराबर 2 P." },
        answer: 2,
      },
      {
        en: { title: "What does ATM stand for?", options: ["Automatic Transfer Machine", "Any Time Money", "Automated Teller Machine", "Account Transfer Method"] },
        hi: { title: "ATM का पूरा नाम क्या है?", options: ["ऑटोमेटिक ट्रांसफर मशीन", "एनी टाइम मनी", "ऑटोमेटेड टेलर मशीन", "अकाउंट ट्रांसफर मेथड"] },
        answer: 2,
      },
      {
        en: { title: "If the ratio of savings to spending is 2:3 and total income is ₹5,000, how much is saved?", options: ["₹1,500", "₹2,000", "₹2,500", "₹3,000"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mfrac><mn>2</mn><mn>5</mn></mfrac><mo>×</mo><mn>5000</mn><mo>=</mo><mo>?</mo></mrow></math>', mathLabel: "2 divided by 5 times 5000 equals question mark." },
        hi: { title: "बचत और खर्च का अनुपात 2:3 है और कुल आय 5,000 रुपये है। बचत कितनी है?", options: ["₹1,500", "₹2,000", "₹2,500", "₹3,000"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mfrac><mn>2</mn><mn>5</mn></mfrac><mo>×</mo><mn>5000</mn><mo>=</mo><mo>?</mo></mrow></math>', mathLabel: "2 बटा 5 गुणा 5000 बराबर प्रश्नवाचक चिन्ह." },
        answer: 1,
      },
    ],
  },
  logical: {
    label: "Logical reasoning",
    subject: "LOGICAL REASONING",
    durationSeconds: 600,
    description: "Sequences, classification, and deductions in accessible formats.",
    questions: [
      {
        en: { title: "Find the next number in the sequence: 3, 6, 12, 24, ?", options: ["36", "42", "48", "54"] },
        hi: { title: "श्रृंखला में अगली संख्या ज्ञात कीजिए: 3, 6, 12, 24, ?", options: ["36", "42", "48", "54"] },
        answer: 2,
      },
      {
        en: { title: "Which one is different from the others?", options: ["Square", "Triangle", "Circle", "Cube"] },
        hi: { title: "इनमें से कौन बाकी से अलग है?", options: ["वर्ग", "त्रिभुज", "वृत्त", "घन"] },
        answer: 3,
      },
      {
        en: { title: "All roses are flowers. Which statement must be true?", options: ["All roses are flowers", "All flowers are roses", "No roses are flowers", "Some roses are not flowers"] },
        hi: { title: "सभी गुलाब फूल हैं। इनमें से कौन सा कथन निश्चित रूप से सही है?", options: ["सभी गुलाब फूल हैं", "सभी फूल गुलाब हैं", "कोई गुलाब फूल नहीं है", "कुछ गुलाब फूल नहीं हैं"] },
        answer: 0,
      },
      {
        en: { title: "What number completes the pattern shown below?", options: ["10", "12", "14", "16"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mn>2</mn><mo>,</mo><mn>4</mn><mo>,</mo><mn>8</mn><mo>,</mo><mn>?</mn></mrow></math>', mathLabel: "2, 4, 8, question mark." },
        hi: { title: "नीचे दिए गए पैटर्न में कौन सी संख्या आएगी?", options: ["10", "12", "14", "16"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mn>2</mn><mo>,</mo><mn>4</mn><mo>,</mo><mn>8</mn><mo>,</mo><mn>?</mn></mrow></math>', mathLabel: "2, 4, 8, प्रश्नवाचक चिन्ह." },
        answer: 3,
      },
      {
        en: { title: "Book is to reading as fork is to:", options: ["Drawing", "Writing", "Eating", "Cooking"] },
        hi: { title: "पुस्तक का संबंध पढ़ने से है, उसी प्रकार कांटे का संबंध किससे है?", options: ["चित्र बनाने", "लिखने", "खाने", "पकाने"] },
        answer: 2,
      },
      {
        en: { title: "If all cats are mammals and Luna is a cat, what must be true?", options: ["Luna is a mammal", "All mammals are cats", "Luna is a bird", "No cats are mammals"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mi>Cats</mi><mo>⊂</mo><mi>Mammals</mi><mo>,</mo><mspace width="0.3em"></mspace><mi>Luna</mi><mo>∈</mo><mi>Cats</mi></mrow></math>', mathLabel: "Cats are a subset of mammals, and Luna belongs to cats." },
        hi: { title: "यदि सभी बिल्लियाँ स्तनधारी हैं और लूना एक बिल्ली है, तो क्या निश्चित रूप से सही है?", options: ["लूना स्तनधारी है", "सभी स्तनधारी बिल्लियाँ हैं", "लूना पक्षी है", "कोई बिल्ली स्तनधारी नहीं है"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mi>Cats</mi><mo>⊂</mo><mi>Mammals</mi><mo>,</mo><mspace width="0.3em"></mspace><mi>Luna</mi><mo>∈</mo><mi>Cats</mi></mrow></math>', mathLabel: "बिल्लियाँ स्तनधारियों का उपसमुच्चय हैं और लूना बिल्लियों में है." },
        answer: 0,
      },
      {
        en: { title: "Which word does not belong with the others?", options: ["Rose", "Lotus", "Oak", "Jasmine"] },
        hi: { title: "इनमें से कौन सा शब्द बाकी से अलग है?", options: ["गुलाब", "कमल", "ओक", "चमेली"] },
        answer: 2,
      },
      {
        en: { title: "A clock shows 3:00. What is the angle between its hands?", options: ["30 degrees", "60 degrees", "90 degrees", "180 degrees"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mi>θ</mi><mo>=</mo><mn>90</mn><mo>°</mo></mrow></math>', mathLabel: "theta equals 90 degrees." },
        hi: { title: "एक घड़ी में 3 बजे हैं। उसकी सुइयों के बीच कोण कितना है?", options: ["30 डिग्री", "60 डिग्री", "90 डिग्री", "180 डिग्री"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mi>θ</mi><mo>=</mo><mn>90</mn><mo>°</mo></mrow></math>', mathLabel: "थीटा बराबर 90 डिग्री." },
        answer: 2,
      },
      {
        en: { title: "Complete the series: 5, 10, 20, 40, ?", options: ["50", "60", "80", "100"] },
        hi: { title: "श्रृंखला पूरी कीजिए: 5, 10, 20, 40, ?", options: ["50", "60", "80", "100"] },
        answer: 2,
      },
      {
        en: { title: "If A is taller than B and B is taller than C, who is shortest?", options: ["A", "B", "C", "Cannot be determined"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mi>A</mi><mo>></mo><mi>B</mi><mo>></mo><mi>C</mi></mrow></math>', mathLabel: "A is greater than B, which is greater than C." },
        hi: { title: "यदि A, B से लंबा है और B, C से लंबा है, तो सबसे छोटा कौन है?", options: ["A", "B", "C", "निर्धारित नहीं किया जा सकता"], mathml: '<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow><mi>A</mi><mo>></mo><mi>B</mi><mo>></mo><mi>C</mi></mrow></math>', mathLabel: "A, B से बड़ा है और B, C से बड़ा है." },
        answer: 2,
      },
    ],
  },
};

const state = {
  currentView: "dashboard",
  testKey: "ssc",
  questionIndex: 0,
  selected: null,
  saved: false,
  seconds: 300,
  timer: null,
  advanceTimer: null,
  reminderMarks: new Set(),
  answers: [],
  latestResultText: "",
  recognition: null,
  loginRecognition: null,
  loginVoiceField: null,
  loginVoiceConfirming: false,
  speechTimer: null,
  lastSpeechText: "",
  lastSpeechAt: 0,
  audioContext: null,
  returnFocus: null,
  user: null,
  language: localStorage.getItem("clearpath-language") || "en",
  textSize: localStorage.getItem("clearpath-text-size") || "default",
};

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

function getCurrentTest() {
  return testCatalog[state.testKey] || testCatalog.ssc;
}

function getCurrentQuestion() {
  const test = getCurrentTest();
  const question = test.questions[state.questionIndex] || test.questions[test.questions.length - 1];
  return {
    ...question,
    content: question[state.language] || question.en,
  };
}

function getLanguageName() {
  return state.language === "hi" ? "Hindi" : "English";
}

function getSpeechLocale() {
  return state.language === "hi" ? "hi-IN" : "en-IN";
}

function getSpeechVoice() {
  if (!("speechSynthesis" in window)) return null;
  const voices = window.speechSynthesis.getVoices();
  const locale = getSpeechLocale().toLowerCase();
  return voices.find((voice) => voice.lang.toLowerCase() === locale)
    || voices.find((voice) => voice.lang.toLowerCase().startsWith(state.language))
    || null;
}

function setLanguage(language, announce = true) {
  state.language = language === "hi" ? "hi" : "en";
  localStorage.setItem("clearpath-language", state.language);
  if ($("#test-language")) $("#test-language").value = state.language;
  if ($("#login-language")) $("#login-language").value = state.language;
  if ($("#login-read-aloud")) {
    $("#login-read-aloud").textContent = state.language === "hi"
      ? "◖ साइन-इन निर्देश सुनें"
      : "◖ Read sign-in instructions aloud";
  }
  if ($("#login-email-voice")) {
    $("#login-email-voice").setAttribute("aria-label", state.language === "hi" ? "ईमेल पता आवाज़ से भरें" : "Enter email address by voice");
  }
  if ($("#login-password-voice")) {
    $("#login-password-voice").setAttribute("aria-label", state.language === "hi" ? "पासवर्ड आवाज़ से भरें" : "Enter password by voice");
  }
  if ($("#test-modal") && !$("#test-modal").hidden) renderQuestion(true);
  if (announce) speak(state.language === "hi" ? "भाषा हिंदी में बदल दी गई है।" : "Language changed to English.");
}

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  announce(message);
  window.clearTimeout(showToast.timeout);
  showToast.timeout = window.setTimeout(() => toast.classList.remove("show"), 2800);
}

function announce(message) {
  const liveAnnouncer = $("#live-announcer");
  if (!liveAnnouncer) return;
  liveAnnouncer.textContent = "";
  window.setTimeout(() => { liveAnnouncer.textContent = message; }, 20);
}

function playAudioCue(kind = "confirm") {
  if (!$("#audio-toggle")?.checked || !window.AudioContext && !window.webkitAudioContext) return;
  const AudioContext = window.AudioContext || window.webkitAudioContext;
  if (!state.audioContext) state.audioContext = new AudioContext();
  const context = state.audioContext;
  if (context.state === "suspended") context.resume();
  const settings = {
    confirm: { frequency: 660, duration: 0.09, type: "sine" },
    navigate: { frequency: 440, duration: 0.08, type: "triangle" },
    warning: { frequency: 260, duration: 0.18, type: "sawtooth" },
    complete: { frequency: 880, duration: 0.12, type: "sine" },
  }[kind] || { frequency: 660, duration: 0.09, type: "sine" };
  const oscillator = context.createOscillator();
  const gain = context.createGain();
  oscillator.type = settings.type;
  oscillator.frequency.value = settings.frequency;
  gain.gain.setValueAtTime(0.0001, context.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.08, context.currentTime + 0.01);
  gain.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + settings.duration);
  oscillator.connect(gain);
  gain.connect(context.destination);
  oscillator.start();
  oscillator.stop(context.currentTime + settings.duration + 0.02);
}

function speak(text, { onend } = {}) {
  if ("speechSynthesis" in window) {
    const now = Date.now();
    if (!onend && text === state.lastSpeechText && now - state.lastSpeechAt < 700) return;
    state.lastSpeechText = text;
    state.lastSpeechAt = now;
    window.speechSynthesis.cancel();
    window.clearTimeout(state.speechTimer);
    state.speechTimer = window.setTimeout(() => {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = getSpeechLocale();
      utterance.voice = getSpeechVoice();
      utterance.rate = 0.93;
      if (onend) utterance.onend = onend;
      window.speechSynthesis.speak(utterance);
    }, 35);
  } else {
    showToast("Speech support is not available in this browser.");
    onend?.();
  }
}

function readCurrentQuestion() {
  if (!$("#speech-toggle").checked || $("#test-modal").hidden) return;
  const optionWord = state.language === "hi" ? "विकल्प" : "Option";
  const question = getCurrentQuestion();
  const options = [...document.querySelectorAll(".answer-option")]
    .map((option, index) => `${optionWord} ${String.fromCharCode(65 + index)}: ${option.innerText}`)
    .join(". ");
  const minutes = Math.floor(state.seconds / 60);
  const seconds = state.seconds % 60;
  const remaining = state.language === "hi"
    ? (minutes > 0 ? `${minutes} मिनट शेष` : `${seconds} सेकंड शेष`)
    : (minutes > 0 ? `${minutes} minute${minutes === 1 ? "" : "s"} remaining` : `${seconds} seconds remaining`);
  const questionNumber = state.language === "hi"
    ? `प्रश्न ${state.questionIndex + 1}, कुल ${getCurrentTest().questions.length} में से।`
    : `Question ${state.questionIndex + 1} of ${getCurrentTest().questions.length}.`;
  speak(`${questionNumber} ${$("#test-title").textContent}. ${question.content.mathLabel ? `${question.content.mathLabel}.` : ""} ${options}. ${remaining}.`);
}

function setView(viewName) {
  state.currentView = viewName;
  $$(".view").forEach((view) => view.classList.toggle("is-visible", view.id === `${viewName}-view`));
  $$(".nav-item").forEach((item) => {
    const active = item.dataset.view === viewName;
    item.classList.toggle("is-active", active);
    if (active) item.setAttribute("aria-current", "page");
    else item.removeAttribute("aria-current");
  });
  const activeNav = $(`.nav-item[data-view="${viewName}"]`);
  $("#page-title").textContent = activeNav ? activeNav.textContent.trim() : viewName;
  const activeView = $(`#${viewName}-view`);
  activeView?.focus({ preventScroll: true });
  playAudioCue("navigate");
  announce(`${activeNav ? activeNav.textContent.trim() : viewName} view opened.`);
  window.scrollTo({ top: 0, behavior: document.body.classList.contains("reduce-motion") ? "auto" : "smooth" });
}

function openTest(testKey = "ssc") {
  state.returnFocus = document.activeElement;
  state.testKey = testKey;
  state.questionIndex = 0;
  state.selected = null;
  state.saved = false;
  state.answers = [];
  state.reminderMarks = new Set();
  state.seconds = getCurrentTest().durationSeconds;
  $("#test-language").value = state.language;
  $("#test-modal").hidden = false;
  document.body.classList.add("modal-open");
  renderQuestion(true);
  startTimer();
  playAudioCue("navigate");
  announce(`${getCurrentTest().label} test started in full screen. Ten questions, ten minutes.`);
  enterTestFullscreen();
  window.setTimeout(() => $(".answer-option")?.focus(), 320);
}

function closeTest() {
  stopVoiceAnswer();
  window.clearTimeout(state.advanceTimer);
  $("#test-modal").hidden = true;
  document.body.classList.remove("modal-open");
  window.clearInterval(state.timer);
  exitTestFullscreen();
  state.returnFocus?.focus?.({ preventScroll: true });
}

function enterTestFullscreen() {
  const target = $("#test-modal");
  document.body.classList.add("test-fullscreen-fallback");
  if (document.fullscreenElement || !target?.requestFullscreen) return;
  target.requestFullscreen().then(() => {
    document.body.classList.remove("test-fullscreen-fallback");
  }).catch(() => {
    showToast("Browser full screen was unavailable, so the test is using the full window instead.");
  });
}

function exitTestFullscreen() {
  if (document.fullscreenElement && document.exitFullscreen) {
    document.exitFullscreen().catch(() => {});
  }
  document.body.classList.remove("test-fullscreen-fallback");
}

function renderQuestion(autoRead = true) {
  const question = getCurrentQuestion();
  const test = getCurrentTest();
  state.selected = state.answers[state.questionIndex] ?? null;
  $("#test-subject").textContent = test.subject;
  $("#test-title").textContent = question.content.title;
  const mathContainer = $("#question-math");
  mathContainer.innerHTML = "";
  if (question.content.mathml) {
    mathContainer.innerHTML = question.content.mathml;
    mathContainer.hidden = false;
    mathContainer.setAttribute("aria-label", question.content.mathLabel || "Mathematical expression");
  } else {
    mathContainer.hidden = true;
    mathContainer.removeAttribute("aria-label");
  }
  $("#question-count").textContent = `Question ${state.questionIndex + 1} of ${test.questions.length}`;
  $("#question-count").setAttribute("aria-label", state.language === "hi"
    ? `प्रश्न ${state.questionIndex + 1}, कुल ${test.questions.length} में से`
    : `Question ${state.questionIndex + 1} of ${test.questions.length}`);
  announce(state.language === "hi"
    ? `प्रश्न ${state.questionIndex + 1}, कुल ${test.questions.length} में से।`
    : `Question ${state.questionIndex + 1} of ${test.questions.length}.`);
  $("#test-progress-fill").style.width = `${((state.questionIndex + 1) / test.questions.length) * 100}%`;
  $(".test-progress").setAttribute("aria-valuenow", String(state.questionIndex + 1));
  renderQuestionPalette();
  $("#previous-question").disabled = state.questionIndex === 0;
  $("#next-question").innerHTML = state.questionIndex === test.questions.length - 1
    ? "Submit test <span aria-hidden=\"true\">✓</span>"
    : "Next question <span aria-hidden=\"true\">→</span>";
  $("#save-question").classList.toggle("is-saved", state.saved);
  $("#save-question").setAttribute("aria-pressed", String(state.saved));
  $("#save-question").innerHTML = `${state.saved ? "★" : "☆"} <span>${state.saved ? "Saved" : "Save question"}</span>`;
  $("#answer-progress").textContent = "";
  $("#timer-announcement").textContent = "";
  const options = $("#answer-options");
  options.innerHTML = "";
  question.content.options.forEach((option, index) => {
    const label = document.createElement("label");
    label.className = "answer-option";
    label.setAttribute("tabindex", "0");
     label.innerHTML = `<input type="radio" name="answer" value="${index}" aria-label="${option}" /><span class="answer-letter" aria-hidden="true">${String.fromCharCode(65 + index)}</span><span>${option}</span>`;
    const input = label.querySelector("input");
     input.checked = state.selected === index;
    input.addEventListener("change", () => selectAnswer(index));
    label.addEventListener("keydown", (event) => {
      if (event.key === " " || event.key === "Enter") {
        event.preventDefault();
        input.checked = true;
        selectAnswer(index);
      }
    });
     label.classList.toggle("selected", state.selected === index);
    options.appendChild(label);
  });
  if (autoRead) {
    window.setTimeout(readCurrentQuestion, 250);
    window.setTimeout(() => $(".answer-option")?.focus(), 320);
  }
}

function renderQuestionPalette() {
  const palette = $("#question-palette-buttons");
  if (!palette) return;
  const test = getCurrentTest();
  palette.innerHTML = "";
  test.questions.forEach((question, index) => {
    const button = document.createElement("button");
    const answered = state.answers[index] !== undefined && state.answers[index] !== null;
    button.type = "button";
    button.className = "question-palette-button";
    button.dataset.questionIndex = String(index);
    button.textContent = String(index + 1);
    button.setAttribute("aria-label", state.language === "hi"
      ? `प्रश्न ${index + 1}${answered ? ", उत्तर दिया गया" : ", उत्तर नहीं दिया गया"}`
      : `Question ${index + 1}${answered ? ", answered" : ", not answered"}`);
    button.setAttribute("aria-current", index === state.questionIndex ? "step" : "false");
    button.classList.toggle("current", index === state.questionIndex);
    button.classList.toggle("answered", answered);
    palette.appendChild(button);
  });
}

function jumpToQuestion(index) {
  const test = getCurrentTest();
  if (index < 0 || index >= test.questions.length || index === state.questionIndex) return;
  window.clearTimeout(state.advanceTimer);
  stopVoiceAnswer();
  state.questionIndex = index;
  state.selected = state.answers[index] ?? null;
  renderQuestion(true);
  playAudioCue("navigate");
}

function queueNextQuestion() {
  window.clearTimeout(state.advanceTimer);
  $("#answer-progress").textContent = state.language === "hi"
    ? "उत्तर चुना गया। अगला प्रश्न खुल रहा है…"
    : "Answer selected. Opening the next question…";
  state.advanceTimer = window.setTimeout(() => {
    if (!$("#test-modal").hidden && state.selected !== null) nextQuestion();
  }, 900);
}

function selectAnswer(index) {
  state.selected = index;
  state.answers[state.questionIndex] = index;
  $$(".answer-option").forEach((option, optionIndex) => option.classList.toggle("selected", optionIndex === index));
  const audioEnabled = $("#audio-toggle").checked;
  if (audioEnabled) playAudioCue("confirm");
  if (audioEnabled) {
    speak(state.language === "hi"
      ? `विकल्प ${String.fromCharCode(65 + index)} चुना गया।`
      : `Answer ${String.fromCharCode(65 + index)} selected.`);
  }
  announce(state.language === "hi"
    ? `विकल्प ${String.fromCharCode(65 + index)} चुना गया।`
    : `Answer ${String.fromCharCode(65 + index)} selected.`);
  queueNextQuestion();
}

function startTimer() {
  window.clearInterval(state.timer);
  updateTimer();
  state.timer = window.setInterval(() => {
    state.seconds -= 1;
    updateTimer();
    if (state.seconds <= 0) {
      window.clearInterval(state.timer);
      playAudioCue("warning");
      showToast("Time is up. Your practice session is being submitted.");
      completeTest();
    }
  }, 1000);
}

function updateTimer() {
  const mins = Math.max(0, Math.floor(state.seconds / 60)).toString().padStart(2, "0");
  const secs = Math.max(0, state.seconds % 60).toString().padStart(2, "0");
  $("#timer-value").textContent = `${mins}:${secs}`;
  $("#timer-value").setAttribute("aria-label", `${mins} minutes ${secs} seconds remaining`);
  const reminderMarks = state.language === "hi"
    ? { 300: "5 मिनट", 180: "3 मिनट", 120: "2 मिनट", 60: "1 मिनट", 30: "30 सेकंड", 10: "10 सेकंड" }
    : { 300: "5 minutes", 180: "3 minutes", 120: "2 minutes", 60: "1 minute", 30: "30 seconds", 10: "10 seconds" };
  if ($("#test-modal") && !$("#test-modal").hidden && reminderMarks[state.seconds] && !state.reminderMarks.has(state.seconds)) {
    state.reminderMarks.add(state.seconds);
    playAudioCue("warning");
    $("#timer-announcement").textContent = state.language === "hi"
      ? `${reminderMarks[state.seconds]} शेष हैं।`
      : `${reminderMarks[state.seconds]} remaining.`;
    if ($("#speech-toggle").checked) {
      speak(state.language === "hi"
        ? `${reminderMarks[state.seconds]} शेष हैं।`
        : `${reminderMarks[state.seconds]} remaining in your ${getCurrentTest().label} test.`);
    }
  }
}

function nextQuestion() {
  window.clearTimeout(state.advanceTimer);
  if (state.selected === null) {
    showToast("Choose an answer before moving on.");
    $("#answer-options").querySelector("label")?.focus();
    return;
  }
  if (state.questionIndex === getCurrentTest().questions.length - 1) {
    completeTest();
    return;
  }
  state.questionIndex += 1;
  state.selected = null;
  renderQuestion(true);
  window.setTimeout(() => $(".answer-option")?.focus(), 320);
}

function previousQuestion() {
  window.clearTimeout(state.advanceTimer);
  if (state.questionIndex === 0) {
    showToast("You are on the first question.");
    return;
  }
  state.questionIndex -= 1;
  renderQuestion(true);
  playAudioCue("navigate");
  announce(`Question ${state.questionIndex + 1} of ${getCurrentTest().questions.length}.`);
  window.setTimeout(() => $(".answer-option")?.focus(), 320);
}

function completeTest() {
  const test = getCurrentTest();
  const total = test.questions.length;
  const correct = test.questions.reduce((score, question, index) => score + (state.answers[index] === question.answer ? 1 : 0), 0);
  const accuracy = Math.round((correct / total) * 100);
  const resultText = state.language === "hi"
    ? `${test.label} परीक्षा पूरी हुई। आपने ${total} में से ${correct} प्रश्न सही किए। आपकी सटीकता ${accuracy} प्रतिशत है।`
    : `${test.label} test complete. You answered ${correct} out of ${total} correctly. Your accuracy is ${accuracy} percent.`;
  state.latestResultText = resultText;
  $("#result-test-name").textContent = test.label;
  $("#result-detail").textContent = state.language === "hi"
    ? `आपने ${total} में से ${correct} प्रश्न सही किए।`
    : `You answered ${correct} of ${total} questions correctly.`;
  $("#result-accuracy").textContent = `${accuracy}%`;
  $("#latest-result").hidden = false;
  closeTest();
  playAudioCue("complete");
  announce(`${test.label} test complete. ${correct} of ${total} correct.`);
  setView("progress");
  showToast(`${test.label} test complete: ${accuracy}% accuracy.`);
  if ($("#speech-toggle").checked) window.setTimeout(() => speak(resultText), 250);
}

function setVoiceStatus(message) {
  $("#voice-status").textContent = message;
}

function finishVoiceUi() {
  state.recognition = null;
  $("#voice-answer").classList.remove("is-listening");
  $("#voice-answer").setAttribute("aria-pressed", "false");
}

function stopVoiceAnswer() {
  if (state.recognition) state.recognition.stop();
  finishVoiceUi();
}

function findVoiceAnswer(transcript) {
  const normalized = transcript.toLowerCase().replace(/[.,!?]/g, " ").replace(/\s+/g, " ").trim();
  const letterMatch = normalized.match(/\b(?:option|answer|choice)?\s*([abcd])\b/);
  if (letterMatch) return letterMatch[1].charCodeAt(0) - 97;
  const numberWords = ["one", "first", "two", "second", "three", "third", "four", "fourth"];
  const numberIndex = numberWords.indexOf(normalized);
  if (numberIndex !== -1) return Math.floor(numberIndex / 2);
  const options = getCurrentQuestion().content.options;
  const textIndex = options.findIndex((option) => normalized.includes(option.toLowerCase().replace(/[.,!?]/g, "")));
  return textIndex;
}

function startVoiceAnswer() {
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Recognition) {
    setVoiceStatus("Voice input is not supported in this browser.");
    showToast("Try Chrome or Edge for microphone answers.");
    return;
  }
  if (state.recognition) {
    stopVoiceAnswer();
    setVoiceStatus("Voice input stopped.");
    return;
  }
  const recognition = new Recognition();
  state.recognition = recognition;
  recognition.lang = state.language === "hi" ? "hi-IN" : "en-IN";
  recognition.interimResults = false;
  recognition.continuous = false;
  recognition.maxAlternatives = 1;
  recognition.onstart = () => {
    $("#voice-answer").classList.add("is-listening");
    $("#voice-answer").setAttribute("aria-pressed", "true");
    setVoiceStatus(state.language === "hi"
      ? "माइक्रोफ़ोन सक्रिय है। विकल्प A, B, C या D बोलें।"
      : "Microphone active. Say option A, B, C, or D.");
    playAudioCue("confirm");
  };
  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript.trim();
    const answerIndex = findVoiceAnswer(transcript);
    if (answerIndex >= 0 && answerIndex < getCurrentQuestion().content.options.length) {
      selectAnswer(answerIndex);
      setVoiceStatus(state.language === "hi"
        ? `“${transcript}” सुना। विकल्प ${String.fromCharCode(65 + answerIndex)} चुना गया।`
        : `Heard “${transcript}”. Answer ${String.fromCharCode(65 + answerIndex)} selected.`);
    } else {
      setVoiceStatus(state.language === "hi"
        ? `“${transcript}” सुना। विकल्प A, B, C या D बोलें।`
        : `Heard “${transcript}”. Say option A, B, C, or D.`);
      showToast(state.language === "hi"
        ? "मैं इसे किसी उत्तर विकल्प से नहीं मिला सका।"
        : "I could not match that to an answer option.");
    }
  };
  recognition.onerror = (event) => {
    if (event.error === "not-allowed" || event.error === "service-not-allowed") {
      setVoiceStatus("Microphone permission was denied.");
      showToast("Allow microphone access to answer by voice.");
    } else if (event.error !== "aborted") {
      setVoiceStatus("Voice input could not start. Try again.");
    }
  };
  recognition.onend = finishVoiceUi;
  try {
    recognition.start();
  } catch (error) {
    finishVoiceUi();
    setVoiceStatus("Voice input is already starting. Try again.");
  }
}

function finishLoginVoice() {
  state.loginRecognition = null;
  state.loginVoiceField = null;
  $$(".field-voice-button").forEach((button) => {
    button.classList.remove("is-listening");
    button.setAttribute("aria-pressed", "false");
  });
}

function normalizeEmailTranscript(transcript) {
  let normalized = transcript
    .toLowerCase()
    .replace(/^(?:my\s+)?(?:email\s+address|email)\s+(?:is|equals)\s+/i, "")
    .replace(/(?:\s+at\s+|\s*@\s*| एट | एटदरेट | at the rate )/gi, "@")
    .replace(/(?:\s+dot\s+|\s*\.\s*| डॉट | बिंदु )/gi, ".")
    .replace(/(?:\s+dash\s+| डैश )/gi, "-")
    .replace(/(?:\s+underscore\s+| अंडरस्कोर )/gi, "_")
    .replace(/(?:\s+space\s+| स्पेस )/gi, "");
  return normalized.replace(/\s+/g, "");
}

function getLoginSpeechValue(fieldId, value) {
  if (fieldId === "login-email") {
    return value.replace(/@/g, state.language === "hi" ? " एट " : " at ")
      .replace(/\./g, state.language === "hi" ? " डॉट " : " dot ");
  }
  return value;
}

function isVoiceConfirmationYes(transcript) {
  const normalized = transcript.toLowerCase().replace(/[.,!?]/g, " ").replace(/\s+/g, " ").trim();
  return /^(yes|yeah|yep|correct|right|okay|ok|true|हां|हाँ|सही|ठीक|ठीक है|बिल्कुल)$/.test(normalized);
}

function isVoiceConfirmationNo(transcript) {
  const normalized = transcript.toLowerCase().replace(/[.,!?]/g, " ").replace(/\s+/g, " ").trim();
  return /^(no|nope|wrong|incorrect|not correct|false|नहीं|नही|गलत|फिर से|दोबारा)$/.test(normalized);
}

function startLoginConfirmation(fieldId, buttonId, value) {
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Recognition) return;
  state.loginVoiceConfirming = true;
  const label = fieldId === "login-email"
    ? (state.language === "hi" ? "ईमेल" : "email address")
    : (state.language === "hi" ? "पासवर्ड" : "password");
  const spokenValue = getLoginSpeechValue(fieldId, value);
  const prompt = state.language === "hi"
    ? `मैंने ${label} ${spokenValue} सुना। क्या यह सही है? सही या गलत बोलें।`
    : `I heard your ${label} as ${spokenValue}. Is that correct? Say yes or no.`;
  speak(prompt, { onend: () => {
    if (state.loginVoiceConfirming) listenForLoginConfirmation(fieldId, buttonId);
  }});
}

function listenForLoginConfirmation(fieldId, buttonId) {
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const recognition = new Recognition();
  state.loginRecognition = recognition;
  recognition.lang = getSpeechLocale();
  recognition.interimResults = false;
  recognition.continuous = false;
  recognition.maxAlternatives = 1;
  recognition.onstart = () => {
    const button = $(`#${buttonId}`);
    button.classList.add("is-listening");
    button.setAttribute("aria-pressed", "true");
    $("#login-voice-status").textContent = state.language === "hi"
      ? "सही या गलत बोलिए।"
      : "Say yes if it is correct, or no to enter it again.";
  };
  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript.trim();
    finishLoginVoice();
    if (isVoiceConfirmationYes(transcript)) {
      state.loginVoiceConfirming = false;
      $("#login-voice-status").textContent = state.language === "hi" ? "जानकारी सही मानी गई।" : "Details confirmed.";
      speak(state.language === "hi" ? "जानकारी सही मानी गई।" : "Details confirmed.");
      return;
    }
    if (isVoiceConfirmationNo(transcript)) {
      state.loginVoiceConfirming = false;
      const input = $(`#${fieldId}`);
      input.value = "";
      input.focus();
      const retryMessage = state.language === "hi"
        ? "ठीक है। इसे फिर से बोलिए।"
        : "Okay. Please say it again.";
      $("#login-voice-status").textContent = retryMessage;
      speak(retryMessage, { onend: () => startLoginVoice(fieldId, buttonId) });
      return;
    }
    state.loginVoiceConfirming = false;
    const unclearMessage = state.language === "hi"
      ? "मैंने सही या गलत स्पष्ट रूप से नहीं सुना। फिर से कोशिश करें।"
      : "I did not hear yes or no clearly. Please try again.";
    $("#login-voice-status").textContent = unclearMessage;
    speak(unclearMessage);
  };
  recognition.onerror = (event) => {
    finishLoginVoice();
    if (event.error !== "aborted") {
      state.loginVoiceConfirming = false;
      showToast(state.language === "hi" ? "पुष्टि सुनाई नहीं दी। फिर से कोशिश करें।" : "I could not hear the confirmation. Try again.");
    }
  };
  recognition.onend = () => {
    if (state.loginRecognition === recognition) finishLoginVoice();
  };
  try {
    recognition.start();
  } catch {
    finishLoginVoice();
    state.loginVoiceConfirming = false;
    showToast(state.language === "hi" ? "पुष्टि फिर से आज़माएँ।" : "Try the confirmation again.");
  }
}

function startLoginVoice(fieldId, buttonId) {
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Recognition) {
    showToast(state.language === "hi"
      ? "इस ब्राउज़र में आवाज़ से लिखना उपलब्ध नहीं है। Chrome या Edge आज़माएँ।"
      : "Voice typing is not supported in this browser. Try Chrome or Edge.");
    return;
  }
  if (state.loginRecognition) {
    state.loginRecognition.stop();
    finishLoginVoice();
    return;
  }
  state.loginVoiceConfirming = false;
  const recognition = new Recognition();
  state.loginRecognition = recognition;
  state.loginVoiceField = fieldId;
  recognition.lang = getSpeechLocale();
  recognition.interimResults = false;
  recognition.continuous = false;
  recognition.maxAlternatives = 1;
  recognition.onstart = () => {
    const button = $(`#${buttonId}`);
    button.classList.add("is-listening");
    button.setAttribute("aria-pressed", "true");
    $("#login-voice-status").textContent = state.language === "hi"
      ? "माइक्रोफ़ोन सक्रिय है। अब बोलिए।"
      : "Microphone active. Speak now.";
    playAudioCue("confirm");
  };
  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript.trim();
    const input = $(`#${fieldId}`);
    const value = fieldId === "login-email" ? normalizeEmailTranscript(transcript) : transcript;
    input.value = value;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.focus();
    finishLoginVoice();
    $("#login-voice-status").textContent = state.language === "hi"
      ? `${fieldId === "login-email" ? "ईमेल" : "पासवर्ड"} सुना गया। पुष्टि की प्रतीक्षा है।`
      : `${fieldId === "login-email" ? "Email address" : "Password"} heard. Waiting for confirmation.`;
    startLoginConfirmation(fieldId, buttonId, value);
  };
  recognition.onerror = (event) => {
    if (event.error === "not-allowed" || event.error === "service-not-allowed") {
      showToast(state.language === "hi"
        ? "आवाज़ से लिखने के लिए माइक्रोफ़ोन की अनुमति दें।"
        : "Allow microphone access to use voice typing.");
    } else if (event.error !== "aborted") {
      showToast(state.language === "hi" ? "आवाज़ इनपुट फिर से आज़माएँ।" : "Voice input could not start. Try again.");
    }
  };
  recognition.onend = () => {
    if (state.loginRecognition === recognition) finishLoginVoice();
  };
  try {
    recognition.start();
  } catch {
    finishLoginVoice();
    showToast(state.language === "hi" ? "आवाज़ इनपुट फिर से आज़माएँ।" : "Try voice input again.");
  }
}

function saveUser(user, remember) {
  const storage = remember ? localStorage : sessionStorage;
  storage.setItem("clearpath-user", JSON.stringify(user));
}

function readSavedUser() {
  for (const storage of [sessionStorage, localStorage]) {
    const saved = storage.getItem("clearpath-user");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        storage.removeItem("clearpath-user");
      }
    }
  }
  return null;
}

function showApp(user) {
  state.user = user;
  $("#login-screen").hidden = true;
  $("#app-shell").hidden = false;
  $("#profile-name").textContent = user.name;
  $("#dashboard-candidate-name").textContent = user.name;
  $("#logout-button").setAttribute("aria-label", `Sign out of ${user.name}`);
}

function readLoginInstructions() {
  speak(state.language === "hi"
    ? "क्लियरपाथ उम्मीदवार साइन इन। अपना ईमेल और पासवर्ड बोलकर या टाइप करके भरें, फिर साइन इन दबाएँ। आप सुलभ डेमो भी इस्तेमाल कर सकते हैं। सहायता के लिए 7805027450 पर कॉल करें।"
    : "ClearPath candidate sign in. Enter your email address and password by voice or keyboard, then press Enter on Sign in. You can also use the accessible demo. For support, call 7805027450.");
}

function showLogin() {
  state.user = null;
  $("#app-shell").hidden = true;
  $("#login-screen").hidden = false;
  setLanguage(state.language, false);
  window.setTimeout(() => {
    $("#login-email").focus();
    readLoginInstructions();
  }, 250);
}

function signIn(email, password, remember = false) {
  const trimmedEmail = email.trim();
  if (!trimmedEmail || !trimmedEmail.includes("@")) {
    $("#login-status").textContent = "Enter a valid email address.";
    $("#login-email").focus();
    return;
  }
  if (password.length < 4) {
    $("#login-status").textContent = "Your password must be at least 4 characters.";
    $("#login-password").focus();
    return;
  }
  const localName = trimmedEmail.split("@")[0].replace(/[._-]+/g, " ").trim();
  const name = localName ? localName.replace(/\b\w/g, (letter) => letter.toUpperCase()) : "ClearPath candidate";
  const user = { name, email: trimmedEmail };
  saveUser(user, remember);
  $("#login-status").textContent = "";
  showApp(user);
  showToast(`Welcome back, ${name}.`);
}

function applyPreferences() {
  const savedTheme = localStorage.getItem("clearpath-dark");
  const savedContrast = localStorage.getItem("clearpath-contrast");
  const savedMotion = localStorage.getItem("clearpath-motion");
  if (savedTheme === "true") { $("#dark-toggle").checked = true; document.body.classList.add("dark-theme"); }
  if (savedContrast === "true") { $("#contrast-toggle").checked = true; document.body.classList.add("high-contrast"); }
  if (savedMotion === "true") { $("#motion-toggle").checked = true; document.body.classList.add("reduce-motion"); }
  applyTextSize(state.textSize);
}

function applyTextSize(size) {
  const values = {
    small: { fontSize: "14px", scale: "0.9" },
    default: { fontSize: "16px", scale: "1" },
    large: { fontSize: "18px", scale: "1.12" },
    xlarge: { fontSize: "20px", scale: "1.25" },
  };
  const selected = values[size] || values.default;
  document.documentElement.style.setProperty("--font-size", selected.fontSize);
  document.documentElement.style.setProperty("--font-scale", selected.scale);
  document.documentElement.dataset.textSize = size;
  $$(".text-size-control button").forEach((button) => button.classList.toggle("selected", button.dataset.textSize === size));
  localStorage.setItem("clearpath-text-size", size);
  state.textSize = size;
}

function readPageSummary() {
  if (state.language === "hi") {
    speak("यह क्लियरपाथ कार्यक्षेत्र है। यहाँ आप परीक्षा अभ्यास, अपनी प्रगति, सहेजे गए प्रश्न और सहायता विकल्प देख सकते हैं।");
    return;
  }
  speak(document.querySelector(".view.is-visible")?.innerText.slice(0, 450) || "ClearPath workspace");
}

function filterPracticeCards(filterValue) {
  $$(".library-card").forEach((card) => {
    card.hidden = filterValue !== "all" && card.dataset.testCard !== filterValue;
  });
  $$(".filter-pill").forEach((pill) => {
    const selected = pill.dataset.filter === filterValue;
    pill.classList.toggle("selected", selected);
    pill.setAttribute("aria-pressed", String(selected));
  });
}

document.addEventListener("click", (event) => {
  const nav = event.target.closest("[data-view]");
  if (nav) setView(nav.dataset.view);
  const target = event.target.closest("[data-view-target]");
  if (target) setView(target.dataset.viewTarget);
  const action = event.target.closest("[data-action]");
  if (action) {
    const { action: type, test } = action.dataset;
    if (type === "open-practice") setView("practice");
    if (type === "start-test") openTest(test || "ssc");
    if (type === "resume-test") openTest(test || "ssc");
  }
  const filter = event.target.closest(".filter-pill");
  if (filter) {
    filterPracticeCards(filter.dataset.filter || "all");
    showToast(`${filter.textContent.trim()} selected`);
  }
  const paletteButton = event.target.closest(".question-palette-button");
  if (paletteButton) jumpToQuestion(Number(paletteButton.dataset.questionIndex));
});

$("#contrast-toggle").addEventListener("change", (event) => {
  document.body.classList.toggle("high-contrast", event.target.checked);
  localStorage.setItem("clearpath-contrast", event.target.checked);
});
$("#dark-toggle").addEventListener("change", (event) => {
  document.body.classList.toggle("dark-theme", event.target.checked);
  localStorage.setItem("clearpath-dark", event.target.checked);
});
$("#motion-toggle").addEventListener("change", (event) => {
  document.body.classList.toggle("reduce-motion", event.target.checked);
  localStorage.setItem("clearpath-motion", event.target.checked);
});
$$("[data-text-size]").forEach((button) => button.addEventListener("click", () => applyTextSize(button.dataset.textSize)));
$("#read-support").addEventListener("click", () => speak(state.language === "hi"
  ? "स्वतंत्र उपयोग के लिए बनाया गया। क्लियरपाथ स्क्रीन रीडर, केवल कीबोर्ड नेविगेशन, स्पष्ट फ़ोकस और हर अभ्यास परीक्षा में अर्थपूर्ण शीर्षकों का समर्थन करता है।"
  : "Designed for independent use. ClearPath supports screen readers, keyboard-only navigation, visible focus states, and semantic headings throughout every practice test."));
$("#announce-button").addEventListener("click", readPageSummary);
$("#read-question").addEventListener("click", () => {
  if (!$("#speech-toggle").checked) { showToast("Read questions aloud is turned off in Accessibility settings."); return; }
  readCurrentQuestion();
});
$("#test-language").addEventListener("change", (event) => setLanguage(event.target.value));
$("#login-language").addEventListener("change", (event) => setLanguage(event.target.value));
$("#save-question").addEventListener("click", () => {
  state.saved = !state.saved;
  renderQuestion(false);
  playAudioCue("confirm");
  showToast(state.saved ? "Question saved for later." : "Question removed from saved.");
});
$("#clear-answer").addEventListener("click", () => {
  window.clearTimeout(state.advanceTimer);
  delete state.answers[state.questionIndex];
  state.selected = null;
  renderQuestion(false);
  playAudioCue("confirm");
  showToast("Answer selection cleared.");
});
$("#voice-answer").addEventListener("click", startVoiceAnswer);
$("#login-email-voice").addEventListener("click", () => startLoginVoice("login-email", "login-email-voice"));
$("#login-password-voice").addEventListener("click", () => startLoginVoice("login-password", "login-password-voice"));
$("#next-question").addEventListener("click", nextQuestion);
$("#previous-question").addEventListener("click", previousQuestion);
$("#read-result").addEventListener("click", () => {
  if (state.latestResultText) speak(state.latestResultText);
});
$("#login-read-aloud").addEventListener("click", readLoginInstructions);
$(".close-test").addEventListener("click", closeTest);
$("#test-modal").addEventListener("click", (event) => { if (event.target.id === "test-modal") closeTest(); });
document.addEventListener("keydown", (event) => {
  if (event.key === "Tab" && !$("#test-modal").hidden) {
    const focusable = [...$("#test-modal").querySelectorAll("button, select, input, [tabindex]:not([tabindex='-1'])")]
      .filter((element) => !element.disabled && element.offsetParent !== null);
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }
  if (event.altKey && event.key.toLowerCase() === "r" && !$("#test-modal").hidden) {
    event.preventDefault();
    $("#read-question").click();
  }
  if (event.key === "Escape" && !$("#test-modal").hidden) closeTest();
});

$("#login-form").addEventListener("submit", (event) => {
  event.preventDefault();
  signIn($("#login-email").value, $("#login-password").value, $("#remember-me").checked);
});
$("#demo-login").addEventListener("click", () => {
  const user = { name: "Alex Nair", email: "alex@example.com" };
  saveUser(user, false);
  $("#login-status").textContent = "";
  showApp(user);
  playAudioCue("confirm");
  showToast("Demo access enabled.");
});
$("#password-toggle").addEventListener("click", () => {
  const password = $("#login-password");
  const visible = password.type === "text";
  password.type = visible ? "password" : "text";
  $("#password-toggle").textContent = visible ? "Show" : "Hide";
  $("#password-toggle").setAttribute("aria-label", visible ? "Show password" : "Hide password");
});
$("#forgot-password").addEventListener("click", () => {
  $("#login-status").textContent = "Password reset support is available through your institution.";
});
$("#logout-button").addEventListener("click", () => {
  sessionStorage.removeItem("clearpath-user");
  localStorage.removeItem("clearpath-user");
  closeTest();
  showLogin();
  showToast("You have been signed out.");
});

applyPreferences();
const savedUser = readSavedUser();
if (savedUser) showApp(savedUser);
else showLogin();